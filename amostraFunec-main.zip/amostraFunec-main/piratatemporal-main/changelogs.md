# piratatemporal

Bruno:

Mudei algumas coisas, arrumei um pouco a animação, digamos que deixei ela um pouco mais fluida e também arrumei aquele probleminha do personagem não tocar 
no chão.

(Porfavor quando forem mudar alguma coisa nesse repositorio editem esse arquivo para que possamos saber quem, quando e o que foi mudado.)
